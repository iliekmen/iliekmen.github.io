var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Feature.ForceTwoStepVerification"] = {"ForceTwoStepVerification.Action":"Set Up","ForceTwoStepVerification.Body":"You must set up 2-Step Verification to complete this action. This will help protect your login, purchases, and more.","ForceTwoStepVerification.Header":"2-Step Verification Required"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.ForceTwoStepVerification");
