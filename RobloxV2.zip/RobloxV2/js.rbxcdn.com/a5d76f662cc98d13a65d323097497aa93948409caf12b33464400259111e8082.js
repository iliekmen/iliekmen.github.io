var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.ForceAuthenticator"] = {"Header.TurnOnAuthenticator":"Turn on Authenticator","Description.SetupAuthenticator":"You must set up 2-Step Verification via Authenticator to complete this action.","Description.Reason":"2 steps of security will protect your login, Robux, big purchases, experiences and more.","Action.Setup":"Set Up"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.ForceAuthenticator");
